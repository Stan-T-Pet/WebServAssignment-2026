Inventory API - Endpoints
OpenAPI JSON: http://api-ci-11:8000/openapi.json
Swagger UI (FastAPI): http://api-ci-11:8000/docs
FastAPI documentation: https://fastapi.tiangolo.com/

GET /
POST /addNew - params: ProductID (query, required, string), Name (query, required, string), UnitPrice (query, required, number), StockQuantity (query, required, integer), Description (query, required, string)
GET /convert/{product_id} - params: product_id (path, required, string)
DELETE /deleteOne/{product_id} - params: product_id (path, required, string)
GET /getAll
GET /getSingleProduct/{product_id} - params: product_id (path, required, string)
GET /metrics
GET /paginate/{start_id}/{end_id} - params: start_id (path, required, string), end_id (path, required, string)
GET /startsWith/{letter} - params: letter (path, required, string)
